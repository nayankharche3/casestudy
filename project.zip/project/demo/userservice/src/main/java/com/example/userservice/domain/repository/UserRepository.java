package com.example.userservice.domain.repository;

        import com.example.userservice.domain.model.User;
        import org.springframework.data.jpa.repository.JpaRepository;
        import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
}