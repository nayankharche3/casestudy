package com.example.blogservice.api.command;


        import com.example.blogservice.application.command.AdminBlogCommandService;
        import org.springframework.http.ResponseEntity;
        import org.springframework.validation.annotation.Validated;
        import org.springframework.web.bind.annotation.*;

        import javax.validation.constraints.Size;

@RestController
@RequestMapping("/api/v1.0/blogsite/admin")
@Validated
public class AdminBlogCommandController {
    private final AdminBlogCommandService adminService;

    public AdminBlogCommandController(AdminBlogCommandService adminService) {
        this.adminService = adminService;
    }

    // Admin can add blogs
    // POST /api/v1.0/blogsite/admin/blogs/add/{blogname}
    @PostMapping("/blogs/add/{blogname}")
    public ResponseEntity<Long> adminAddBlog(@PathVariable("blogname") @Size(min = 20, max = 200) String blogname,
                                             @RequestParam @Size(min = 20, max = 200) String category,
                                             @RequestParam @Size(min = 1000) String article,
                                             @RequestParam @Size(min = 3, max = 100) String authorName,
                                             @RequestHeader("X-USER-ROLE") String role,
                                             @RequestHeader("X-OWNER-ID") Long ownerId) {
        if (!"ADMIN".equals(role)) {
            return ResponseEntity.status(403).build();
        }
        Long id = adminService.adminAddBlog(blogname, category, article, authorName, ownerId);
        return ResponseEntity.ok(id);
    }
}