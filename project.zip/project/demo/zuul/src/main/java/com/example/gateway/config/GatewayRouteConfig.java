package com.example.gateway.config;


        import com.example.gateway.filter.AuthenticationFilter;
        import org.springframework.cloud.gateway.route.RouteLocator;
        import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
        import org.springframework.context.annotation.Bean;
        import org.springframework.context.annotation.Configuration;
@Configuration
public class GatewayRouteConfig {
    @Bean
    public RouteLocator routes(RouteLocatorBuilder builder,
                               AuthenticationFilter authFilter) {
        return builder.routes()
                // USER SERVICE ROUTES
                .route("user-service", r -> r
                        .path("/api/v1.0/blogsite/user/**")
//                        .filters(f -> f.filter(authFilter.apply(new AuthenticationFilter.Config())))
                        .uri("http://localhost:8091") // ✅ corrected
                )
                // BLOG SERVICE ROUTES
                .route("blog-service", r -> r
                        .path("/api/v1.0/blogsite/blogs/**")
//                        .filters(f -> f.filter(authFilter.apply(new AuthenticationFilter.Config())))
                        .uri("http://localhost:8090") // ✅ corrected
                )
                .build();
    }
}